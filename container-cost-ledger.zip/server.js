// Minimal server for hosting the Container Cost Ledger dashboard.
// Render (and most hosts) set PORT automatically — we just need to listen on it.

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve everything in /public (index.html, and any assets you add later)
app.use(express.static(path.join(__dirname, 'public')));

// Fallback: always serve the dashboard for any route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Container Cost Ledger running on port ${PORT}`);
});
